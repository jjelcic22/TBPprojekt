# Pokretanje projekta — kratka provjera

Ovo je kratak checklist potreban da profesor može reproducirati izvođenje skripti i notebooka (bez pinanja verzija paketa).

## Preduvjeti
- Python 3.8 ili noviji
- Pokrenut MongoDB server, dostupan na `mongodb://localhost:27017` (zadani port 27017)
- Raw JSON datoteke nalaze se u `podaci/raw/` (npr. `stanovi-api-detail-*.json`, `kuce-api-detail-*.json`)

## Instalacija Python paketa
1. (Opcionalno) Kreirajte i aktivirajte virtualno okruženje:
   - Windows: `python -m venv .venv` i `.
.venv\Scripts\activate`
   - Unix/macOS: `python -m venv .venv` i `source .venv/bin/activate`
2. Instalirajte potrebne pakete:
   ```bash
   python -m pip install -r requirements.txt
   ```

## Učitavanje podataka u MongoDB
- Pokrenite skriptu iz root direktorija `Projekt`:
  ```bash
  python -m skripte.load_mongo
  # ili: python skripte\load_mongo.py
  ```
- Skripta će indeksirati kolekciju i upsert-ati dokumente iz `podaci/raw/*.json`.
- Na kraju ispisuje približan broj upsertanih/dodanih dokumenata i ukupni broj u kolekciji.

## Pokretanje Jupyter notebooka
- Pokrenite:
  ```bash
  jupyter notebook notebooks/mapReduce.ipynb
  ```
  ili otvorite `notebooks/mapReduce.ipynb` u VS Code (Notebook editor).
- Pokrenite ćelije počevši od **1) Setup**.



