from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional

from dateutil import parser as dateparser
from pymongo import MongoClient, UpdateOne
from pymongo.collection import Collection
from tqdm import tqdm

BASE_DIR = Path(__file__).resolve().parents[1]  # Projekt/
RAW_DIR = BASE_DIR / "podaci" / "raw"           
DB_NAME = "nekretnine"
COLL_NAME = "listings"
MONGO_URI = "mongodb://localhost:27017"


def parse_dt(value: Any) -> Optional[datetime]:
    if value is None:
        return None
    try:
        dt = dateparser.isoparse(str(value))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def map_location(loc: Any) -> Dict[str, Optional[str]]:
    if isinstance(loc, list):
        parts = [str(x).strip() if x is not None else None for x in loc]
    else:
        parts = []
    def get(i: int) -> Optional[str]:
        return parts[i] if i < len(parts) else None

    country = get(0)
    if country and country.upper() == "HRVATSKA":
        country = "HR"

    return {
        "country": country,
        "county": get(1),
        "city": get(2),
        "neighborhood": get(3),
    }


def infer_types(categories: Any) -> Dict[str, Optional[str]]:
    listing_type = None
    property_type = None

    cat0 = None
    if isinstance(categories, list) and categories:
        cat0 = str(categories[0]).lower()

    if cat0:
        if cat0.startswith("prodaja-"):
            listing_type = "sale"
        elif cat0.startswith("najam-") or cat0.startswith("iznajmljivanje-"):
            listing_type = "rent"

        if "kuca" in cat0:
            property_type = "house"
        elif "stan" in cat0:
            property_type = "apartment"

    return {"listingType": listing_type, "propertyType": property_type}


def transform(doc: Dict[str, Any]) -> Dict[str, Any]:
    perm = doc.get("permutiveData") or {}
    creator = doc.get("creator") or {}

    ad_code = perm.get("adCode")
    _id = f"index:{ad_code}" if ad_code is not None else None

    types = infer_types(perm.get("categories"))

    out: Dict[str, Any] = {
        "_id": _id,
        "source": "index.hr",
        "postedAt": parse_dt(doc.get("postedTime")),
        "scrapedAt": parse_dt(doc.get("scrape_date")),
        "listingType": types["listingType"],
        "propertyType": types["propertyType"],
        "price": {
            "amount": doc.get("price"),
            "currency": doc.get("priceCurrency"),
            "perM2": doc.get("priceM2"),
        },
        "area": {
            "livingM2": doc.get("area"),
            "gardenM2": doc.get("gardenArea"),
        },
        "rooms": doc.get("numberOfRooms"),
        "yearBuilt": parse_dt(doc.get("yearBuilt")),
        "floor": {
            "position": doc.get("flatFloorPosition"),
        },
        "building": {
            "houseType": doc.get("houseType"),
            "flatType": doc.get("flatType"),
            "floors": doc.get("numberOfFloors"),
            "stories": doc.get("numberOfStories"),
        },
        "features": {
            "garden": doc.get("garden"),
            "noEnclosedCarPark": doc.get("noEnclosedCarPark"),
            "parkingSpaces": doc.get("numberOfParkingSpaces"),
            "airConditioner": doc.get("airConditioner"),
            "cityGas": doc.get("cityGas"),
            "cityWaterSupply": doc.get("cityWaterSupply"),
            "citySewerage": doc.get("citySewerage"),
            "newBuild": doc.get("newBuild"),
            "buildingPermit": doc.get("buildingPermit"),
            "usePermit": doc.get("usePermit"),
            "ownershipCertificate": doc.get("ownershipCertificate"),
            "heatingSystem": doc.get("heatingSystem") if isinstance(doc.get("heatingSystem"), list) else [],
        },
        "location": map_location(perm.get("location")),
        "seller": {
            "id": creator.get("id") or doc.get("creatorId"),
            "name": creator.get("username"),
            "legalEntity": creator.get("legalEntity"),
            "verified": creator.get("isVerified"),
        },
        "stats": {
            "views": doc.get("viewCount"),
            "imageCount": doc.get("imageCount"),
        },
    }

    if out["_id"] is None:
        # ako nema adCode, fallback: hash URL-a ili kombinacija 
        raise ValueError("Nedostaje permutiveData.adCode - ne mogu složiti _id")

    return out


def iter_docs_from_file(path: Path) -> Iterable[Dict[str, Any]]:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
        if isinstance(data, list):
            for d in data:
                if isinstance(d, dict):
                    yield d


def ensure_indexes(coll: Collection) -> None:
    coll.create_index([("location.city", 1), ("propertyType", 1), ("listingType", 1)])
    coll.create_index([("price.amount", 1)])
    coll.create_index([("price.perM2", 1)])
    coll.create_index([("scrapedAt", -1)])
    coll.create_index([("seller.id", 1)])


def main() -> None:
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    coll = db[COLL_NAME]

    ensure_indexes(coll)

    files = sorted(RAW_DIR.glob("*.json")) 
    #files = sorted(RAW_DIR.glob("*.json"))[:1] # privremeno
    if not files:
        raise SystemExit(f"Nema .json datoteka u {RAW_DIR.resolve()}")

    batch: List[UpdateOne] = []
    BATCH_SIZE = 1000
    total = 0

    for file in files:
        for d in tqdm(iter_docs_from_file(file), desc=f"Ucitavam {file.name}"):
            t = transform(d)
            _id = t["_id"]
            batch.append(UpdateOne({"_id": _id}, {"$set": t}, upsert=True))

            if len(batch) >= BATCH_SIZE:
                res = coll.bulk_write(batch, ordered=False)
                total += res.upserted_count + res.modified_count
                batch.clear()

    if batch:
        res = coll.bulk_write(batch, ordered=False)
        total += res.upserted_count + res.modified_count

    print(f"Gotovo. Upsert/updated approx: {total}")
    print("Ukupno dokumenata u listings:", coll.count_documents({}))


if __name__ == "__main__":
    main()
